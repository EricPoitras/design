/**
 * Example Designing a Problem and Solution 1105
 * @author Eric Poitras
 * @version 23-02-2022
 */

import java.util.Scanner;

public class ExampleDesign1105 {
    public static void main(String[] args){
        Scanner kb = new Scanner(System.in);

        int count = kb.nextInt();
        String[] product = new String[count];

        for(int i = 0; i < product.length; i++){
            product[i] = kb.next();
        }

        String[] listNames = new String[count];
        int[] listCounts = new int[count];
        int listCounter = 1;

        for(int i = 0; i < product.length; i++){
            boolean targetIsMatch = false;
            for(int j = 0; j < listCounter; j++){
                if(product[i].equals(listNames[j])){
                    targetIsMatch = true;
                    listCounts[j]++;
                }
            }
            if(!targetIsMatch) {
                listNames[listCounter - 1] = product[i];
                listCounts[listCounter - 1] = 1;
                listCounter++;
            }
        }

        for(int i = 0; i < listCounter - 1; i++){
            System.out.println(listNames[i] + " " + listCounts[i]);
        }
    }
}
